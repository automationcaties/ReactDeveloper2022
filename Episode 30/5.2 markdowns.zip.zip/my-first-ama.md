---
title: 'My First AMA'
date: '2017-08-21'
description: 'My first AMA :)'
---

Thank you everyone who enjoyed the AMA! It was my first one and I'd love to do it again.

<iframe width="560" height="315" src="https://www.youtube.com/embed/DXJO3AraeMQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

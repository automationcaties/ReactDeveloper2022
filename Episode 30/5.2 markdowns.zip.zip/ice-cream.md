---
title: "Why I Love Ice Cream"
date: "2017-08-10"
---

### Ice cream is the best.

I scream, you scream, we all scream, because there's no more ice cream. No one's rhyming about spinach.

Here is a description of this heavenly nectar from wikipedia on [ice cream](https://en.wikipedia.org/wiki/Ice_cream): 

> Ice cream (derived from earlier iced cream or cream ice)is
> a sweetened frozen food typically eaten as a snack or 
> dessert. It may be made from dairy milk or cream, or soy, 
> cashew, coconut or almond milk, and is flavored with a 
> sweetener, either sugar or an alternative, and any spice, 
> such as cocoa or vanilla. Colourings are usually added, in 
> addition to stabilizers. The mixture is stirred to 
> incorporate air spaces and cooled below the freezing point 
> of water to prevent detectable ice crystals from forming. 
> The result is a smooth, semi-solid foam that is solid at 
> very low temperatures (below 2 °C or 35 °F). It becomes 
> more malleable as its temperature increases.